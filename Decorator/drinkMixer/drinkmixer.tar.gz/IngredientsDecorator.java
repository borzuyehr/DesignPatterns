
public abstract class IngredientsDecorator extends Drink {
	Drink drink;

}
