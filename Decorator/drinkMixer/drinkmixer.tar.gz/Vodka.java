public class Vodka extends Drink {

	public Vodka() {
		description = "Vodka";
	}

	public double calories() {
		return 30;
	}

}
