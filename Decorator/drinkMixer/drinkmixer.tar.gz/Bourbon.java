public class Bourbon extends Drink {

	public Bourbon() {
		description = "bourbon";
	}

	public double calories() {
		return 80;
	}

}
