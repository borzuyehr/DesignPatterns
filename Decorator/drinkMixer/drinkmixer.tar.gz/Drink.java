public abstract class Drink {
	Drink drink;
	String description = "unknown Drink";

public String getDescription() {
	return description;
}

public abstract double calories();

}