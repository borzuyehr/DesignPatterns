
public abstract class Hero {
	Hero hero;
	String description = "unknown Hero";

public String getDescription() {
	return description;
}

public abstract double homeLandSize();
}
