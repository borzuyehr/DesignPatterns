public class Stark extends Hero {

	public Stark() {
		description = "House Stark";
	}

	public double homeLandSize() {
		return 100;
	}

}