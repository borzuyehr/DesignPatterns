
public class Lannister extends Hero{

	public Lannister() {
		description = "House Lannister";
	}

	public double homeLandSize() {
		return 500;
	}
}
