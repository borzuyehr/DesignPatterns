
public abstract class QualityDecorator extends Hero{
	Hero hero;
}
